CREATE TABLE `mch_payment_collection` (
	`id` BIGINT(19) NOT NULL AUTO_INCREMENT,
	`code` VARCHAR(100) NULL DEFAULT NULL COMMENT '編碼' COLLATE 'utf8mb4_general_ci',
	`description` VARCHAR(255) NULL DEFAULT NULL COMMENT '描述' COLLATE 'utf8mb4_general_ci',
	`user_group_id` BIGINT(19) NULL DEFAULT NULL COMMENT 'mch_user_group主鍵',
	`active` TINYINT(3) NULL DEFAULT '1' COMMENT '是否啟用1為啟用，0位不啟用',
	`del_flag` TINYINT(3) NULL DEFAULT '0' COMMENT '是否刪除1為刪除，0位不刪除',
	`start_date` DATE NULL DEFAULT NULL COMMENT '开始日期',
	`end_date` DATE NULL DEFAULT NULL COMMENT '結束日期',
	`create_by` VARCHAR(255) NULL DEFAULT NULL COMMENT '創建人' COLLATE 'utf8mb4_general_ci',
	`create_time` DATETIME NULL DEFAULT NULL COMMENT '創建時間',
	`updated_by` VARCHAR(255) NULL DEFAULT NULL COMMENT '更新人' COLLATE 'utf8mb4_general_ci',
	`updated_time` DATETIME NULL DEFAULT NULL COMMENT '更新時間',
	PRIMARY KEY (`id`) USING BTREE,
	INDEX `idx_mkbt_user_group_id` (`user_group_id`) USING BTREE
)
COMMENT='key_brand_template'
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1733903890
;
