CREATE TABLE `mch_payment_collection_biz_map` (
	`id` BIGINT(19) NOT NULL,
	`payment_collection_id` BIGINT(19) NULL DEFAULT NULL COMMENT 'payment_collectionid',
	`store_id` BIGINT(19) NULL DEFAULT NULL COMMENT 'store_id',
	`active` TINYINT(3) NULL DEFAULT '1' COMMENT '是否啟用1為啟用，0位不啟用',
	`del_flag` TINYINT(3) NULL DEFAULT '0' COMMENT '是否刪除1為刪除，0位不刪除',
	`create_by` VARCHAR(255) NULL DEFAULT NULL COMMENT '創建人' COLLATE 'utf8mb4_general_ci',
	`create_time` DATETIME NULL DEFAULT NULL COMMENT '創建時間',
	`updated_by` VARCHAR(255) NULL DEFAULT NULL COMMENT '更新人' COLLATE 'utf8mb4_general_ci',
	`updated_time` DATETIME NULL DEFAULT NULL COMMENT '更新時間',
	PRIMARY KEY (`id`) USING BTREE,
	INDEX `idx_mumbm_id_biztype` (`store_id`, `payment_collection_id`) USING BTREE
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;
